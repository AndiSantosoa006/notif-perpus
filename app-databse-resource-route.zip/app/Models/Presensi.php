<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Presensi extends Model
{
    use HasFactory;

    // Mengizinkan kolom ini diisi secara massal
    protected $fillable = [
        'nomor_wa',
        'koordinat',
    ];
}
